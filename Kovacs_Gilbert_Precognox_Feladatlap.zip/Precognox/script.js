let chosenSize = 0;
let log = false;
let counter = 1;
let result = [];
let len = 3;

function tableSizeRequest(){
    let size = document.getElementById("size").value;
    chosenSize = size;

    if(chosenSize > 3){
        len = 4;
    }

    console.log(len);

}

function sizeCheck(){
    let size = document.getElementById("size").value;

    if(size >= 3 && size <= 7){
        tableSizeRequest();
        log = true;

    }else{
        alert("Please give me a valid size:(");
    }
}




function writeTheLetter(which){
    let maxCount = Math.pow(chosenSize, 2);


    if(counter <= maxCount){
        if(counter % 2 === 0){
            step_O(which);
            document.getElementById("whoseTurn").innerHTML ="Player One's turn";
            createResultMatrix(0);
        }else{
            step_X(which);
            document.getElementById("whoseTurn").innerHTML ="Player Second's turn";
            createResultMatrix(1);
        }

    }
    counter++;
    console.log(counter);

}


function step_X(which){
    which.innerHTML = "X";
    lastTwoNumber(which, "X");
    calcResult("X");
}

function step_O(which){
    which.innerHTML = "O";
    lastTwoNumber(which, "O");
    calcResult("O");
}





function createPlayfield(){

    var table = document.createElement("table");
    var tr = document.createElement("tr");
    var td = document.createElement("td");





if(log) {
    for (let i = 0; i < chosenSize; i++) {
        tr = document.createElement("tr");
        tr.id = "tr" + (i + 1);

        for (let j = 0; j < chosenSize; j++) {
            td = document.createElement("td");
            td.id = ("td"+ i) + j;
            tr.appendChild(td);
            td.setAttribute("onclick" , "writeTheLetter("+ td.id +")");



        }

        table.appendChild(tr)

    }

    createResultMatrix();
    console.log(result)
}else{
    alert("Sorry, but you gave me bad size:(")
}

document.body.appendChild(table);
document.getElementById("whoseTurn").innerHTML ="Player One's turn";
}


function createResultMatrix(){
    for(let i=0; i< chosenSize; i++) {
         let matrix  = [];
        for(let j=0; j< chosenSize; j++) {
            matrix.push('');
        }
    result.push(matrix);
}


}


function lastTwoNumber(place, letter){

    let a = place.id;
    console.log(typeof a);
    let i = a[a.length - 2];
    let j = a[a.length - 1];

    result[i][j] = letter;

}


function calcResult(letter){

        for (let i = 0; i < chosenSize; i++) {
            let db = 0;
            for (let j = 0; j < chosenSize; j++) {
                if (result[i][j] === letter) {
                    db++;
                }

                if (db === len) {
                    alert("Meg van a győztes");
                    break;
                }
            }
    }


    for (let j = 0; j < chosenSize; j++) {
        let db = 0;
        for (let i = 0; i < chosenSize; i++) {
            if (result[i][j] === letter) {
                db++;
            }

            if (db === len) {
                alert("Meg van a győztes");
                break;
            }
        }
    }


    for (let i = 0; i < chosenSize; i++) {
        let db = 0;
        for (let j = 0; j < chosenSize; j++) {
            if(j === i && result[i][j] === letter){
                db++;
            }


            if (db === len) {
                alert("Meg van a győztes");
                break;
            }
        }
    }



}













